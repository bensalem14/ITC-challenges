function linearSearch(arr, key) {
  for (let i = 0; i < arr.length; i++) if (arr[i] == key) return i;
  return -1;
}
console.log(
  " array " +
    [1, 2, 3, 5, 9] +
    " key " +
    9 +
    " answer " +
    linearSearch([1, 2, 3, 5, 9], 9)
);
