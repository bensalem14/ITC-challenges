#include <bits/stdc++.h>
using namespace std;
list<int> create(int arr[], int size)
{
    int i = 0;
    list<int> mylist;
    for (i = 0; i < size; i++)
    {
        mylist.push_back(arr[i]);
    }
    return mylist;
}
list<int> remove(list<int> mylist)
{
    int i = 0;
    list<int> result;
    set<int> set;
    for (list<int>::iterator head = mylist.begin(); head != mylist.end(); head++)
    {
        set.insert(*head);
    }
    for (auto it = set.begin(); it != set.end(); it++)
    {
        result.push_back(*it);
    }

    return result;
}

void print(list<int> const &list)
{
    for (auto const &i : list)
    {
        cout << i << "-->";
    }
}

int main()
{
    int arr[] = {1, 1, 2, 2, 6, 5, 9};
    list<int> l = create(arr, 7);
    cout << "1 1 2 2 6 5 9" << endl;
    print(remove(l));
}