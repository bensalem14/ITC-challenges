function convert(str) {
  if (/[^\d\-\+]/.test(str)) return "bad string value";
  else if (!Number.isInteger(Number(str))) return "bad string value";
  else return parseInt(str) || "bad string value";
}

console.log(convert("-001-1"));
