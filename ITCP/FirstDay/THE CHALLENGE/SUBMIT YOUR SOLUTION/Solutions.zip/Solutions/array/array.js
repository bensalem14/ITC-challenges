function merge(arr1, arr2) {
  total = [...arr1, ...arr2].sort();
  arr1 = total.slice(0, arr1.length);
  arr2 = total.slice(arr1.length);
  console.log(arr1, arr2);
}
merge([0, 2, 4, 6, 8], [1, 3, 5, 7]);
