function dist(p1, p2) {
  return Math.sqrt(Math.pow(p1[0] - p2[0], 2) + Math.pow(p1[1] - p2[1], 2));
}
function bruteForce(nPoints) {
  let min = Infinity;
  let d = 0;
  for (let i = 0; i < nPoints.length; i++)
    for (let j = i + 1; j < nPoints.length; j++) {
      d = dist(nPoints[i], nPoints[j]);
      min = d < min ? d : min;
    }

  return min;
}

console.log(
  [
    [1, 2],
    [5, 9],
    [2, 8],
    [6, 9],
    [3, 9],
  ],
  bruteForce([
    [1, 2],
    [5, 9],
    [2, 8],
    [6, 9],
    [3, 9],
  ])
);
