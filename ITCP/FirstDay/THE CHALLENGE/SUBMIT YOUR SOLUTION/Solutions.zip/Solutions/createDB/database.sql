Create DATABASE ITC;

CREATE TABLE
    Student (
        id INT AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(30) NOT NULL,
        email VARCHAR(50)
    );

CREATE TABLE
    Prof (
        id INT AUTO_INCREMENT PRIMARY KEY,
        firstname VARCHAR(30) NOT NULL,
        email VARCHAR(50),
        spe VARCHAR(30) NOT NULL
    );

INSERT INTO
    Student (firstname, email)
VALUES (
        "ahmed amine",
        "ahmed05@gmail.com"
    );

INSERT INTO
    Student (firstname, email)
VALUES (
        "djamel omar",
        "omar@gmail.com"
    );

INSERT INTO
    Prof (firstname, email, spe)
VALUES (
        "samet",
        "mout@gmail.com",
        "math"
    );

INSERT INTO
    Prof (firstname, email, spe)
VALUES (
        "nafakh",
        "kalb@gmail.com",
        "info"
    );

ALTER TABLE Prof ADD years INT;

UPDATE Prof SET years = 20 WHERE spe="math";